<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use AppBundle\Entity\Area;
use AppBundle\Entity\Country;

/**
 * Company
 *
 * @ORM\Table(name="company")
 * @ORM\Entity(repositoryClass="AppBundle\Repository\CompanyRepository")
 */
class Company
{
    protected $tenders = array();

    /**
     * @ORM\ManyToOne(targetEntity="Area", inversedBy="companies")
     * @ORM\JoinColumn(name="area_id", referencedColumnName="id")
     */
    private $area;

    /**
     * @ORM\ManyToOne(targetEntity="Country", inversedBy="companies")
     * @ORM\JoinColumn(name="country_id", referencedColumnName="id")
     */
    private $country;

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="area_id", type="integer")
     */
    private $areaId;

    /**
     * @var int
     *
     * @ORM\Column(name="country_id", type="integer")
     */
    private $countryId;

    /**
     * @var string
     *
     * @ORM\Column(name="company_name", type="string", length=50)
     */
    private $companyName;

    /**
     * @var string
     *
     * @ORM\Column(name="company_site", type="string")
     */
    private $companySite;

    /**
     * @var string
     *
     * @ORM\Column(name="select_rules", type="string", length=100)
     */
    private $selectRules;

    /**
     * @var string
     *
     * @ORM\Column(name="title_rules", type="string", length=100)
     */
    private $titleRules;

    /**
     * @var string
     *
     * @ORM\Column(name="link_rules", type="string", length=100)
     */
    private $linkRules;

    /**
     * @var string
     *
     * @ORM\Column(name="content_rules", type="string", length=100, nullable=true)
     */
    private $contentRules;

    /**
     * @var bool
     *
     * @ORM\Column(name="status", type="boolean", length=1)
     */
    private $status;

    /**
     * @var string
     *
     * @ORM\Column(name="cookie", type="string", length=500, nullable=true)
     */
    private $cookie;
    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set areaId
     *
     * @param integer $areaId
     *
     * @return Company
     */
    public function setAreaId($areaId)
    {
        $this->areaId = $areaId;

        return $this;
    }

    /**
     * Get areaId
     *
     * @return int
     */
    public function getAreaId()
    {
        return $this->areaId;
    }

    /**
     * Set countryId
     *
     * @param integer $countryId
     *
     * @return Company
     */
    public function setCountryId($countryId)
    {
        $this->countryId = $countryId;

        return $this;
    }

    /**
     * Get countryId
     *
     * @return int
     */
    public function getCountryId()
    {
        return $this->countryId;
    }

    /**
     * Set companyName
     *
     * @param string $companyName
     *
     * @return Company
     */
    public function setCompanyName($companyName)
    {
        $this->companyName = $companyName;

        return $this;
    }

    /**
     * Get companyName
     *
     * @return string
     */
    public function getCompanyName()
    {
        return $this->companyName;
    }

    /**
     * Set companySite
     *
     * @param string $companySite
     *
     * @return Company
     */
    public function setCompanySite($companySite)
    {
        $this->companySite = $companySite;

        return $this;
    }

    /**
     * Get companySite
     *
     * @return array
     */
    public function getCompanySite()
    {
        /*if($this->companySite)*/
            return $this->companySite;
    }

    public function getSitesArray(){
        return explode(',', $this->getCompanySite());
    }

    public function setArea(Area $area){
        $this->area = $area;
        $this->setAreaId($area->getId());
        return $this;
    }

    public function getArea(){
        return $this->area;
    }

    public function setCountry(Country $country){
        $this->country = $country;
        $this->setCountryId($country->getId());
        return $this;
    }

    public function getCountry(){
        return $this->country;
    }

    public function setSiteUrl($siteUrl){

    }
    public function getSiteUrl(){

    }

    /**
     * Set selectRules
     *
     * @param string $selectRules
     *
     * @return Company
     */
    public function setSelectRules($selectRules)
    {
        $this->selectRules = $selectRules;

        return $this;
    }

    /**
     * Get selectRules
     *
     * @return string
     */
    public function getSelectRules()
    {
        return $this->selectRules;
    }
    

    /**
     * Set linkRules
     *
     * @param string $linkRules
     *
     * @return Company
     */
    public function setLinkRules($linkRules)
    {
        $this->linkRules = $linkRules;

        return $this;
    }

    /**
     * Get linkRules
     *
     * @return string
     */
    public function getLinkRules()
    {
        return $this->linkRules;
    }

    /**
     * Set contentRules
     *
     * @param string $contentRules
     *
     * @return Company
     */
    public function setContentRules($contentRules)
    {
        $this->contentRules = $contentRules;

        return $this;
    }

    /**
     * Get contentRules
     *
     * @return string
     */
    public function getContentRules()
    {
        return $this->contentRules;
    }

    /**
     * Set titleRules
     *
     * @param string $titleRules
     *
     * @return Company
     */
    public function setTitleRules($titleRules)
    {
        $this->titleRules = $titleRules;

        return $this;
    }

    /**
     * Get titleRules
     *
     * @return string
     */
    public function getTitleRules()
    {
        return $this->titleRules;
    }


    /**
     * Set status
     *
     * @param boolean $status
     *
     * @return Company
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return boolean
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * add Tenders
     * @param Tenders $tenders
     *
     */
    public function addTenders(Tenders $tenders){
        array_unshift($this->tenders, $tenders);
        return $this;
    }

    public function getTenders(){
        return $this->tenders;
    }

    /**
     * Set cookie
     *
     * @param string $cookie
     *
     * @return Company
     */
    public function setCookie($cookie)
    {
        $this->cookie = $cookie;

        return $this;
    }

    /**
     * Get cookie
     *
     * @return string
     */
    public function getCookie()
    {
        return $this->cookie;
    }
}
