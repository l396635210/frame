<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Company;
use AppBundle\Entity\Country;
use AppBundle\Entity\Sites;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Form\CompanyType;

class CompanyController extends Controller
{
    /**
     * @Route("/admin/company/list", name="company_list")
     */
    public function listAction(Request $request)
    {
        $areaRepository = $this->getDoctrine()->getRepository('AppBundle:Area');
        $areaList = $areaRepository->findAll();

        $repository = $this->getDoctrine()->getRepository('AppBundle:Company');
        $list = $repository->findAll();
        // replace this example code with whatever you need
        return $this->render('company/list.html.twig', array(
            'active'    => $request->get('_route'),
            'list'      => $list,
            'areaList'  => $areaList,
        ));
    }

    /**
     * @Route("/admin/company/create", name="company_create")
     */
    public function createAction(Request $request)
    {
        $company = new Company();
        $form = $this->createForm(CompanyType::class, $company);

        $form->handleRequest($request);

        if( $form->isSubmitted() && $form->isValid() ){

            $em = $this->getDoctrine()->getManager();
            $company = $form->getData();
            $company->setStatus(true);
            $em->persist($company);
            //$this->setSites($company, $em);

            $em->flush();
            $this->addFlash(
                'notice',
                '添加'.$company->getCompanyName().'成功!'
            );

            return $this->redirectToRoute('company_list');
        }
        // replace this example code with whatever you need
        return $this->render('company/create.html.twig', array(
            'active' => $request->get('_route'),
            'action' => 'Create',
            'form'   => $form->createView(),
        ));
    }

    /**
     * @Route("/admin/company/edit/{id}", name="company_edit")
     */
    public function editAction(Request $request, $id)
    {
        $companyRepository = $this->getDoctrine()->getRepository('AppBundle:Company');
        $company = $companyRepository->find($id);
        $form = $this->createForm(CompanyType::class, $company);

        $form->handleRequest($request);

        if( $form->isSubmitted() && $form->isValid() ){

            $em = $this->getDoctrine()->getManager();
            $company = $form->getData();
            $em->persist($company);
            //$this->setSites($company, $em);
            $em->flush();

            $this->addFlash(
                'notice',
                '修改'.$company->getCompanyName().'成功!'
            );

            return $this->redirectToRoute('company_list');
        }

        // replace this example code with whatever you need
        return $this->render('company/create.html.twig', array(
            'active' => $request->get('_route'),
            'action' => 'Edit',
            'form'   => $form->createView(),
        ));
    }

    //添加site表 未使用
    protected function setSites(Company $company, $em){
        //$sitesRepository = $this->getDoctrine()->getRepository('AppBundle:Sites');
        foreach($company->getSitesArray() as $url){
            $sites = new Sites();
            $sites->setCompany($company);
            $sites->setSiteUrl($url);
            $em->persist($sites);
        }
    }
}
