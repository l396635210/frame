<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/5/20
 * Time: 18:56
 */

namespace AppBundle\Service;


class Mail
{
    private $mailer;
    protected $mailBody;

    public function __construct(\Swift_Mailer $mailer)
    {
        $this->mailer = $mailer;
    }

    protected function setMailBody( $list ){
        foreach( $list as $item ){
            dump($item->getCompany()->getCompanyName());
            $this->mailBody .= $item->getCompany()->getCompanyName()."----".$item->getTime()->format('H:i:s').":".$item->getDescription()."\n";
        }
    }

    public function sendNewTendersToEmp($em){
        $empRepository = $em->getRepository('AppBundle:Emp');
        $list = $empRepository->findAll();
        $crawlerLogRepository = $em->getRepository('AppBundle:CrawlerLog');
        foreach( $list as $item ){
            $crawlerLogs = $crawlerLogRepository->findByCompaniesDate($item->getCompany(), new \DateTime());
            $this->setMailBody($crawlerLogs);
            $message = \Swift_Message::newInstance()
                ->setSubject('今日招标更新提醒')
                ->setFrom('18701124322@163.com')
                ->setTo($item->getEmpMail())
                ->setBody($this->mailBody)
            ;
            $this->mailer->send($message);
        }
    }
}