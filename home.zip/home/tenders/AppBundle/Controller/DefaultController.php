<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Tenders;
use AppBundle\Service\DomGrab;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\DomCrawler\Crawler;
use Goutte\Client;
use Symfony\Component\BrowserKit\Cookie;

class DefaultController extends Controller
{
    protected $linkRoles;
    protected $newestTender;
    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/index.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
        ));
    }

    /**
     * @Route("/admin", name="admin")
     */
    public function adminAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/admin.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
            'active'   => $request->get('_route'),
        ));
    }

    /**
     * @Route("/testSites", name="testSites")
     */
    public function testSitesAction(Request $request){
        $client = new DomGrab();

        /*try{*/
            /*$cookie[] = new Cookie('UserName', 'enertech');
            $cookie[] = new Cookie('MemberId', 2065);
            $cookie[] = new Cookie('Nama_Toko', 'PT.Enertech+Indo');
            $cookie[] = new Cookie('PHPSESSID', 'b197f04556654b8c9a600cccee65d87f');
            foreach($cookie as $item){
                $client->getCookieJar()->set($item);
            }*/
            $crawler = $client->request('GET', 'https://iocletenders.gov.in/nicgep/app?page=FrontEndLatestActiveTenders&service=page');

            foreach($client->parseRules($crawler, 'table#table>tr[class!=list_header]')->slice(0,20) as $node){
                $node = new Crawler($node);

                dump($node->html());//选择

                dump($client->parseTitle($node, 'td|4'));//标题
                $title = $client->parseTitle($node, 'td|4');

                dump($client->parseLink($node, 'a[title="View Tender Information"]'));//链接
                $link = $client->parseLink($node, 'a[title="View Tender Information"]');

                dump($link);

                $link = $crawler->selectLink($link)->link();

                dump($link->getUri());

                $crawlerChild = $client->request('GET', $link->getUri());
                dump($client->parseRules($crawlerChild, "td.page_content")->text());
                /**/
            }

        /*}catch(\Exception $e){
            dump($e);
        }*/
        dump($crawler);
        die;
                                //抓取

        die;
        $items = $crawler->filter('table#tblGlobal>tbody>tr>td>span:lt(10)')->each(function (Crawler $node, $i) {
            return trim($node->filter($this->linkRoles)->text());
        });

        return $this->render('base.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
        ));
    }

    /**
     * @Route("/test", name="test")
     */
    public function testAction(Request $request){
        // make a real request to an external site
        $client = new Client();


// select the form and fill in some values
        /*$form = $crawler->selectButton('Login')->form();
        $form['Username'] = 'xiaoyao71';
        $form['Password'] = 'yaoyao1991';*/
// submit that form
        /*$crawler = $client->submit($form);*/
        /*$cookie[] = new Cookie('UserName', 'enertech');
        $cookie[] = new Cookie('MemberId', 2065);
        $cookie[] = new Cookie('Nama_Toko', 'PT.Enertech+Indo');
        $cookie[] = new Cookie('PHPSESSID', '40836e1266de7862cbad5c9f0bf1ef15');
        foreach($cookie as $item){
            $client->getCookieJar()->set($item);
        }
        dump($client->getCookieJar()->all());*/
        $crawler = $client->request('GET', 'http://tender-indonesia.com/tender_home/');
//        $crawler = $client->request('GET', 'http://tender-indonesia.com/Project_room/Index_info.php');
        dump($crawler->html());die;
        // replace this example code with whatever you need
        return $this->render('base.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
        ));
    }

    /**
     * @Route("/mail", name="mail")
     */
    public function mailAction(Request $request)
    {
        $message = \Swift_Message::newInstance()
            ->setSubject('Hello Email')
            ->setFrom('18701124322@163.com')
            ->setTo('396635210@qq.com')
            ->setBody('test a mail'
                /*$this->renderView(
                // app/Resources/views/Emails/registration.html.twig
                    'Emails/registration.html.twig',
                    array('name' => $name)
                ),
                'text/html'*/
            )
            /*
             * If you also want to include a plaintext version of the message
            ->addPart(
                $this->renderView(
                    'Emails/registration.txt.twig',
                    array('name' => $name)
                ),
                'text/plain'
            )
            */
        ;

       /* $message = \Swift_Message::newInstance()
            ->setSubject('招标提醒')
            ->setFrom('18701124322@163.com')
            ->setTo('396635210@qq.com')
            ->setBody('网站已经更新共条数据')
        ;*/
        dump($message);
        //$this->get('mailer')->send($message);

        /*$message = \Swift_Message::newInstance()
            ->setSubject('招标提醒')
            ->setFrom('18701124322@163.com')
            ->setTo('396635210@qq.com')
            ->setBody('格鲁石油网站已经更新,5条数据')
        ;*/

        echo $this->get('mailer')->send($message);
        // replace this example code with whatever you need
        return $this->render('base.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
        ));
    }
}
