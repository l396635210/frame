<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Tenders;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

class TendersController extends Controller
{
    /**
     * @Route("/admin/tenders/list/{page}", name="tenders_list", defaults={"page" = 1})
     */
    public function listAction(Request $request, $page){
        $tendersRepository = $this->getDoctrine()->getRepository('AppBundle:Tenders');
        $pagination = $tendersRepository->findByPage($this->get('knp_paginator'), $request);

        return $this->render('tenders/list.html.twig', [
            'pagination'    => $pagination,
            'active'        => $request->get('_route')
        ]);
    }

}
