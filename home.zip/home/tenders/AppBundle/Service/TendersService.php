<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/5/16
 * Time: 20:26
 */
namespace AppBundle\Service;

use AppBundle\Entity\Company;
use Doctrine\ORM\EntityManager;
use Symfony\Component\DomCrawler\Crawler;
use AppBundle\Entity\Tenders;

class TendersService{

    protected $tenders;

    public function getTenders(){
        return $this->tenders;
    }

    public function setTenders(Company $company, $title, $link, Crawler $crawler, DomGrab $domGrab){
        $tenders = new Tenders();
        $tenders->setCompany($company);
        $tenders->setTitle($title);
        $link = $crawler->selectLink( preg_replace("/\s\s+/", " ", $link) )->link();
        /* 抓取文章详情页 内容
        $crawlerChild = $domGrab->request('GET', $link->getUri());
        if($company->getContentRules()){
            $tenders->setContent(trim($domGrab->parseRules($crawlerChild, $company->getContentRules())->text()));
        }
        */
        $tenders->setUrl($link->getUri());
        $tenders->setDate(new \DateTime('now'));
        $tenders->setTime(new \DateTime('now'));
        $tenders->setTenderNum(1);
        $this->tenders = $tenders;
        return $this;
    }

    public function persist(EntityManager $em){
        $em->persist($this->tenders);
    }

}