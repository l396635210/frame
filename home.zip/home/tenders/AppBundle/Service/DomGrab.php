<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/5/16
 * Time: 20:26
 */
namespace AppBundle\Service;

use Symfony\Component\DomCrawler\Crawler;
use Goutte\Client;
use Symfony\Component\BrowserKit\Cookie;

class DomGrab extends Client{

    public function parseRules(Crawler $crawler, $rules){
        if( strpos( $rules,  '|' ) ){
            $rules = explode('|', $rules);
            list($filter, $eq) = array($rules[0], count($rules)==2?$rules[1]:0 );
            return $crawler->filter($filter)->eq($eq);
        }
        return $crawler->filter($rules);
    }

    public function parseLink(Crawler $crawler, $rules){
        if($this->parseRules($crawler, $rules)->getNode(0)){
            $link = trim($this->parseRules($crawler, $rules)->text());
            return preg_replace("/\s\s+/", " ", $link);
        }
    }

    public function parseTitle(Crawler $crawler, $rules){
        if($this->parseRules($crawler, $rules)->getNode(0)) {
            $title = trim($this->parseRules($crawler, $rules)->text());
            return preg_replace("/\s\s+/", " ", $title);
        }
    }

    public function parseContent(Crawler $crawler, $rules){
        if($this->parseRules($crawler, $rules)->getNode(0)) {
            $title = trim($this->parseRules($crawler, $rules)->text());
            return preg_replace("/\s\s+/", " ", $title);
        }
    }

    /**
     * @param array $cookies
     */
    public function setCookie($cookies){
        if($cookies){
            foreach($cookies as $key=>$val ){
                $cookie = new Cookie($key, $val);
                $this->getCookieJar()->set($cookie);
            }
        }
    }
}