<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Emp;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Repository\EmpRepository;
use AppBundle\Form\EmpType;

class EmpController extends Controller
{
    /**
     * @Route("/admin/emp/list", name="emp_list")
     */
    public function listAction(Request $request)
    {
        $empRepository = $this->getDoctrine()->getRepository("AppBundle:Emp");
        $list = $empRepository->findAll();
        // replace this example code with whatever you need
        return $this->render('emp/list.html.twig', array(
            'active' => $request->get('_route'),
            'list' => $list,
        ));
    }

    /**
     * @Route("/admin/emp/create", name="emp_create")
     */
    public function createAction(Request $request)
    {
        $emp = new emp();
        $form = $this->createForm(EmpType::class, $emp);

        $form->handleRequest($request);

        if( $form->isSubmitted() && $form->isValid() ){
            $emp = $form->getData();
            $emp->setStatus(true);
            $em = $this->getDoctrine()->getManager();
            $em->persist($emp);
            $em->flush();

            $this->addFlash(
                'notice',
                '添加'.$emp->getEmpName().'成功!'
            );

            return $this->redirectToRoute('emp_list');
        }
        // replace this example code with whatever you need
        return $this->render('emp/create.html.twig', array(
            'active' => $request->get('_route'),
            'form'   => $form->createView(),
        ));
    }

    /**
     * @Route("/admin/emp/edit/{id}", name="emp_edit")
     */
    public function editAction(Request $request, $id)
    {
        $empRepository = $this->getDoctrine()->getRepository('AppBundle:Emp');
        $emp = $empRepository->find($id);
        $form = $this->createForm(EmpType::class, $emp);

        $form->handleRequest($request);

        if( $form->isSubmitted() && $form->isValid() ){
            $emp = $form->getData();

            $em = $this->getDoctrine()->getManager();
            $em->flush();

            $this->addFlash(
                'notice',
                '添加'.$emp->getEmpName().'成功!'
            );

            return $this->redirectToRoute('emp_list');
        }
        // replace this example code with whatever you need
        return $this->render('emp/create.html.twig', array(
            'active' => $request->get('_route'),
            'form'   => $form->createView(),
        ));
    }
}
