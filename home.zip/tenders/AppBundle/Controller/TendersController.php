<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Tenders;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\DomCrawler\Crawler;
use Goutte\Client;

class DefaultController extends Controller
{
    /**
     * @Route("/admin/spider", name="spider")
     */
    public function toDoAction(Request $request)
    {
        $areaRepository = $this->getDoctrine()->getRepository("AppBundle:Area");
        $areaList = $areaRepository->findAll();

        $countryRepository = $this->getDoctrine()->getRepository("AppBundle:Country");
        $countryRepository->findBy(array('area_id'=>$request->request->get('area_id')));
        // replace this example code with whatever you need
        return $this->render('tenders/list.html.twig', array(
            '$areaList' => $areaList,

        ));
    }

    /**
     * @Route("/admin", name="admin")
     */
    public function adminAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/admin.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
        ));
    }

    /**
     * @Route("/test", name="test")
     */
    public function testAction(Request $request){
        $companyRepository = $this->getDoctrine()->getRepository("AppBundle:Company");
        $list = $companyRepository->findBy(array('areaId'=>5));

        $em = $this->getDoctrine()->getManager();
        $client = new Client();
        foreach($list as $company){
            $sites = $company->getCompanySite();
            foreach($sites as $site){
                $crawler = $client->request('GET', $site);
                $items = $crawler->filter('div.news')->each(function (Crawler $node, $i) {

                    return trim($node->filter('a.desc')->text());
                });
                //dump($items);
                foreach($items as $k=>$item){
                    $tenders = new Tenders();
                    $tenders->setCompanyId($company->getId());
                    $tenders->setTitle($item);
                    $link = $crawler->selectLink($item)->link();
                    $crawlerChild = $client->request('GET', $link->getUri());
                    $tenders->setContent(trim($crawlerChild->filter('div.text')->text()));
                    $tenders->setDate(new \DateTime('now'));
                    $tenders->setTenderNum(1);
                    $em->persist($tenders);
                }

                $message = \Swift_Message::newInstance()
                    ->setSubject('招标提醒')
                    ->setFrom('18701124322@163.com')
                    ->setTo('396635210@qq.com')
                    ->setBody($company->getCompanyName().'网站已经更新共'.$k.'条数据')
                ;
                $this->get('mailer')->send($message);
            }
            $em->flush();
            dump($sites);
        }
        // replace this example code with whatever you need
        return $this->render('default/admin.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
        ));
    }

    /**
     * @Route("/mail", name="mail")
     */
    public function mailAction(Request $request)
    {
        $message = \Swift_Message::newInstance()
            ->setSubject('Hello Email')
            ->setFrom('18701124322@163.com')
            ->setTo('396635210@qq.com')
            ->setBody('test a mail'
                /*$this->renderView(
                // app/Resources/views/Emails/registration.html.twig
                    'Emails/registration.html.twig',
                    array('name' => $name)
                ),
                'text/html'*/
            )
            /*
             * If you also want to include a plaintext version of the message
            ->addPart(
                $this->renderView(
                    'Emails/registration.txt.twig',
                    array('name' => $name)
                ),
                'text/plain'
            )
            */
        ;

       /* $message = \Swift_Message::newInstance()
            ->setSubject('招标提醒')
            ->setFrom('18701124322@163.com')
            ->setTo('396635210@qq.com')
            ->setBody('网站已经更新共条数据')
        ;*/
        dump($message);
        $this->get('mailer')->send($message);
        // replace this example code with whatever you need
        return $this->render('default/admin.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
        ));
    }
}
