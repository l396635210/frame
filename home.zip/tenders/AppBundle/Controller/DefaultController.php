<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Tenders;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\DomCrawler\Crawler;
use Goutte\Client;

class DefaultController extends Controller
{
    protected $linkRoles;
    protected $newestTender;
    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/index.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
        ));
    }

    /**
     * @Route("/admin", name="admin")
     */
    public function adminAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/admin.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
            'active'   => $request->get('_route'),
        ));
    }

    /**
     * @Route("/testSites", name="testSites")
     */
    public function testSitesAction(Request $request){
        $client = new Client();

        try{
            $crawler = $client->request('GET', 'https://buy.cnooc.com.cn/cbjyweb/001/001001/moreinfo.html');
            foreach($crawler->filter('li.now-hd-items')->slice(0,20) as $node){
                $node = new Crawler($node);
                //dump($node->html());
                dump($node->filter('a.now-link')->eq(0)->text());//标题
                dump($node->filter('a')->text());//链接
                /*$link = $crawler->selectLink($node->filter('tr')->text())->link();
                dump($link->getUri());*/
            }

        }catch(\Exception $e){
            dump($e);
        }
        dump($crawler);
        die;
                                //抓取

        die;
        $items = $crawler->filter('table#tblGlobal>tbody>tr>td>span:lt(10)')->each(function (Crawler $node, $i) {
            return trim($node->filter($this->linkRoles)->text());
        });

        return $this->render('base.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
        ));
    }

    /**
     * @Route("/test", name="test")
     */
    public function testAction(Request $request){
        $companyRepository = $this->getDoctrine()->getRepository("AppBundle:Company");
        $tendersRepository = $this->getDoctrine()->getRepository("AppBundle:Tenders");
        $list = $companyRepository->findBy(array('areaId'=>5));

        $em = $this->getDoctrine()->getManager();
        $client = new Client();
        foreach($list as $company){
            $sites = $company->getCompanySite();
            //$tender = $tendersRepository->findOneBy(array('companyId'=>$company->getId()), array('id'=>'DESC'), 1);

            $mailBody= "招标更新：\n"; $num = 0;
            foreach($sites as $site){
                $crawler = $client->request('GET', 'http://www.oil-india.com/GlobalTenders.aspx');

                //if($tender && strstr($crawler->text(), $tender->getTitle())) break;

                $this->linkRoles = $company->getLinkRules();
                dump($crawler->filter('table#tblGlobal>tbody>tr>td>span:lt(10)'));die;
                $items = $crawler->filter('table#tblGlobal>tbody>tr>td>span:lt(10)')->each(function (Crawler $node, $i) {
                    return trim($node->filter($this->linkRoles)->text());
                });
                foreach($items as $k=>$item){
                    $tenders = new Tenders();
                    $tenders->setCompanyId($company->getId());
                    $tenders->setTitle($item);
                    $link = $crawler->selectLink($item)->link();
                    $crawlerChild = $client->request('GET', $link->getUri());
                    $tenders->setContent(trim($crawlerChild->filter($company->getContentRules())->text()));
                    $tenders->setDate(new \DateTime('now'));
                    $tenders->setTenderNum(1);
                    $em->persist($tenders);
                    $num++;
                }

            }
            $mailBody .= $company->getCompanyName().":".$num."条数据";
        }
        #$body = "格鲁尼亚石油网站已经更新，共5条数据";

        #$body = "格鲁尼亚石油网站已经更新,5条数据";
        $message = \Swift_Message::newInstance()
            ->setSubject('招标提醒')
            ->setFrom('18701124322@163.com')
            ->setTo('396635210@qq.com')
            ->setBody($mailBody)
        ;

        echo $this->get('mailer')->send($message);
        //$em->flush();
        dump($mailBody);
        // replace this example code with whatever you need
        return $this->render('base.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
        ));
    }

    /**
     * @Route("/mail", name="mail")
     */
    public function mailAction(Request $request)
    {
        $message = \Swift_Message::newInstance()
            ->setSubject('Hello Email')
            ->setFrom('18701124322@163.com')
            ->setTo('396635210@qq.com')
            ->setBody('test a mail'
                /*$this->renderView(
                // app/Resources/views/Emails/registration.html.twig
                    'Emails/registration.html.twig',
                    array('name' => $name)
                ),
                'text/html'*/
            )
            /*
             * If you also want to include a plaintext version of the message
            ->addPart(
                $this->renderView(
                    'Emails/registration.txt.twig',
                    array('name' => $name)
                ),
                'text/plain'
            )
            */
        ;

       /* $message = \Swift_Message::newInstance()
            ->setSubject('招标提醒')
            ->setFrom('18701124322@163.com')
            ->setTo('396635210@qq.com')
            ->setBody('网站已经更新共条数据')
        ;*/
        dump($message);
        //$this->get('mailer')->send($message);

        /*$message = \Swift_Message::newInstance()
            ->setSubject('招标提醒')
            ->setFrom('18701124322@163.com')
            ->setTo('396635210@qq.com')
            ->setBody('格鲁石油网站已经更新,5条数据')
        ;*/

        echo $this->get('mailer')->send($message);
        // replace this example code with whatever you need
        return $this->render('base.html.twig', array(
            'base_dir' => realpath($this->container->getParameter('kernel.root_dir').'/..'),
        ));
    }
}
