<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Company;
use AppBundle\Entity\CrawlerLog;
use AppBundle\Entity\Tenders;
use AppBundle\Service\CompanyService;
use AppBundle\Service\DomGrab;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\DomCrawler\Crawler;
use Goutte\Client;

class CrawlerController extends Controller
{

    protected $mailBody= "";

    /**
     * @Route("/admin/spider", name="crawler_spider")
     */
    public function spiderAction(Request $request)
    {
        $areaRepository = $this->getDoctrine()->getRepository("AppBundle:Area");
        $areaList = $areaRepository->findAll();

        $countryRepository = $this->getDoctrine()->getRepository("AppBundle:Country");
        if($request->request->get('area'))
            $countryList = $countryRepository->findBy(array('area'=>$request->request->get('area')));
        else
            $countryList = $countryRepository->findAll();

        $companyRepository = $this->getDoctrine()->getRepository('AppBundle:Company');
        if($request->request->get('area'))
            $companyList = $companyRepository->findBy(array('area'=>$request->request->get('area')));
        elseif($request->request->get('company'))
            $companyList = $companyRepository->findBy(array('company'=>$request->request->get('company')));
        else
            $companyList = $companyRepository->findAll();


        return $this->render('crawler/index.html.twig', array(
            'areaList'      => $areaList,
            'countryList'   => $countryList,
            'companyList'   => $companyList,
            'active'        => $request->get('_route'),
        ));
    }

    /**
     * @Route("/admin/asyncCrawler", name="crawler_asyncDo")
     */
    public function asyncGrabAction(Request $request){
        $companyRepository = $this->getDoctrine()->getRepository("AppBundle:Company");
        $tendersRepository = $this->getDoctrine()->getRepository("AppBundle:Tenders");

        $list = $companyRepository->findForCrawler($request);

        $domGrab = new DomGrab();
        $companyService = new CompanyService();

        foreach($list as $company){
            $crawlerLog = new CrawlerLog();
            /*try{*/

                $sites = $company->getSitesArray();
                //数据库中该公司最后一条招标信息
                $tender = $tendersRepository->findOneBy(array('companyId'=>$company->getId()), array('id'=>'DESC'), 1);

                $num = 0;
                foreach($sites as $site){

                    $crawler = $domGrab->request('GET', $site);
                    foreach($domGrab->parseRules($crawler, $company->getSelectRules())->slice(0,20) as $node){
                        $node = new Crawler($node);
                        dump($node->html());
                        if($tender && strstr(trim($domGrab->parseRules($node, $company->getTitleRules())->text()), $tender->getTitle()))
                            break;

                        $link = trim($domGrab->parseRules($node, $company->getLinkRules())->text());
                        $title = trim($domGrab->parseRules($node, $company->getTitleRules())->text());
                        if($title){
                            $companyService->addTenders($company, $title, $link, $crawler, $domGrab);
                            $num++;
                        }

                    }

                }
                $this->mailBody .= $company->getCompanyName().":".$num."条数据\n";
                $crawlerLog->setCrawlerCount($num);
                $crawlerLog->setIsSuccess(true);
  /*          }catch(\Exception $e){
                $this->mailBody .= $company->getCompanyName()."抓取数据失败\n";
                $crawlerLog->setCrawlerCount(0);
                $crawlerLog->setIsSuccess(false);
                dump($e);
            }*/
            $crawlerLog->setCompany($company);
            $crawlerLog->setDate(new \DateTime('now'));
            $crawlerLog->setTime(new \DateTime('now'));
            $em = $this->getDoctrine()->getManager();
            $em->persist($crawlerLog);
            $companyService->persistTenders($em);
            $this->sendMail();

            $em->flush();
        }

        $response['data'] = $this->mailBody;
        $serializer = $this->get('serializer');
        $response = $serializer->serialize($response, 'json');
        return new JsonResponse($response);
    }

    protected function sendMail(){
        $empRepository = $this->getDoctrine()->getRepository('AppBundle:Emp');
        $list = $empRepository->findAll();
        foreach( $list as $item ){

            $message = \Swift_Message::newInstance()
                ->setSubject('今日招标更新提醒')
                ->setFrom('18701124322@163.com')
                ->setTo($item->getEmpMail())
                ->setBody($this->mailBody)
            ;
            $this->get('mailer')->send($message);
        }
    }

}
