<?php
/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 2016/5/10
 * Time: 16:42
 */

namespace AppBundle\Form;

use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;

class CompanyType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('area', EntityType::class, array('class'=>'AppBundle:Area','choice_label'=>'areaName'
                ,'label'=>'选择地区', 'auto_initialize'=>'全部' , 'attr'=>array('class'=>'form-control')))
            ->add('country', EntityType::class, array('class'=>'AppBundle:Country','choice_label'=>'countryName'
                ,'label'=>'选择国家' , 'attr'=>array('class'=>'form-control')))
            ->add('companyName', TextType::class, array('label'=>'公司名称'
                , 'attr'=>array('class'=>'form-control', 'placeholder'=>'请输入公司名称，最多不超过25个字')))
            ->add('siteUrl', TextType::class, array('label'=>'填写网址'
                ,'attr'=>array('class'=>'form-control')))
            ->add('selectRules', TextType::class, array('label'=>'填写选择规则'
                ,'attr'=>array('class'=>'form-control')))
            ->add('titleRules', TextType::class, array('label'=>'填写标题规则'
                ,'attr'=>array('class'=>'form-control')))
            ->add('linkRules', TextType::class, array('label'=>'填写跳转详情规则'
                ,'attr'=>array('class'=>'form-control')))
            ->add('contentRules', TextType::class, array('label'=>'填写详情页内容规则'
                ,'attr'=>array('class'=>'form-control')))
            ->add('CompanySite', HiddenType::class, array('attr'=>array('class'=>'form-control')))
        ;

    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'AppBundle\Entity\Company'
        ));
    }
}