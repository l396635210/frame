<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/5/16
 * Time: 20:26
 */
namespace AppBundle\Service;

use Symfony\Component\DomCrawler\Crawler;
use Goutte\Client;

class DomGrab extends Client{


    public function parseRules(Crawler $crawler, $rules){
        if( strpos( $rules,  '|' ) ){
            $rules = explode('|', $rules);
            list($filter, $eq) = array($rules[0], count($rules)==2?$rules[1]:0 );
            dump($crawler->filter($filter)->eq($eq)->html());
            return $crawler->filter($filter)->eq($eq);
        }
        return $crawler->filter($rules);
    }

    public function parseLink(Crawler $crawler, $rules){
        return trim($this->parseRules($crawler, $rules)->text());
    }

    public function parseTitle(Crawler $crawler, $rules){
        $title = trim($this->parseRules($crawler, $rules)->text());
        return preg_replace("/\s\s+/", " ", $title);
    }
}